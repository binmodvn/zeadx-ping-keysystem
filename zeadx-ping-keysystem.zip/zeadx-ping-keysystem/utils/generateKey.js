const crypto = require('crypto');

/**
 * Sinh một key kích hoạt theo định dạng: ZEADX-XXXX-XXXX-XXXX
 * Sử dụng crypto.randomBytes để đảm bảo tính ngẫu nhiên an toàn.
 */
function generateKey(prefix = 'ZEADX') {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // bỏ ký tự dễ nhầm (0,O,1,I)
  const segment = () => {
    let s = '';
    const bytes = crypto.randomBytes(4);
    for (let i = 0; i < 4; i++) {
      s += chars[bytes[i] % chars.length];
    }
    return s;
  };

  return `${prefix}-${segment()}-${segment()}-${segment()}`;
}

module.exports = generateKey;
