// Middleware bảo vệ các route quản trị (tạo key, thu hồi key, xem danh sách)
// Yêu cầu header: x-admin-secret: <ADMIN_SECRET trong .env>
function adminAuth(req, res, next) {
  const provided = req.headers['x-admin-secret'];
  const expected = process.env.ADMIN_SECRET;

  if (!expected) {
    return res.status(500).json({ error: 'ADMIN_SECRET chưa được cấu hình trên server.' });
  }

  if (!provided || provided !== expected) {
    return res.status(401).json({ error: 'Không có quyền truy cập. Thiếu hoặc sai admin secret.' });
  }

  next();
}

module.exports = adminAuth;
