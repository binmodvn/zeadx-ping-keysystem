# Zeadx Ping - Hệ thống Key Kích hoạt

Hệ thống quản lý key kích hoạt dùng Node.js + Express + SQLite (better-sqlite3).

## Cài đặt

```bash
npm install
cp .env.example .env
# Mở .env và đổi ADMIN_SECRET thành một chuỗi bí mật riêng của bạn
npm start
```

Server chạy mặc định tại `http://localhost:3000`.

## Các API

Tất cả route quản trị yêu cầu header:
```
x-admin-secret: <ADMIN_SECRET của bạn trong .env>
```

### 1. Tạo key mới (admin)
```
POST /api/keys/generate
Headers: x-admin-secret: <secret>
Body (JSON):
{
  "label": "Khách hàng A",     // tuỳ chọn
  "expiresInDays": 30           // tuỳ chọn, số ngày hết hạn
}
```
Trả về:
```json
{ "key": "ZEADX-XXXX-XXXX-XXXX", "label": "Khách hàng A", "expires_at": "2026-09-04T..." }
```

### 2. Kiểm tra key (dùng trong phần mềm/bot của bạn, không cần admin secret)
```
POST /api/keys/verify
Body (JSON):
{ "key": "ZEADX-XXXX-XXXX-XXXX" }
```
Trả về `{ "valid": true, ... }` hoặc `{ "valid": false, "reason": "..." }`.

### 3. Thu hồi key (admin)
```
POST /api/keys/revoke
Headers: x-admin-secret: <secret>
Body: { "key": "ZEADX-XXXX-XXXX-XXXX" }
```

### 4. Xem danh sách toàn bộ key (admin)
```
GET /api/keys
Headers: x-admin-secret: <secret>
```

## Tích hợp vào bot/phần mềm của bạn

Khi phần mềm khởi động, gọi `POST /api/keys/verify` với key người dùng nhập vào.
Nếu `valid: true` thì cho phép chạy tiếp, ngược lại từ chối và hiển thị `reason`.

## Lưu ý bảo mật

- Không commit file `.env` thật (chứa `ADMIN_SECRET`) lên git.
- Đổi `ADMIN_SECRET` thành chuỗi dài, ngẫu nhiên trước khi deploy.
- Cân nhắc dùng HTTPS khi deploy lên môi trường thật để tránh lộ key qua mạng.
